#!/bin/bash


####################################################################################################
########## 初始化 ##################################################################################
export LANGUAGE="utf-8"
#export LANGUAGE="gbk"

LOCAL_TMP_DIR="/tmp/deploy_tools/$USER"

BLACKLIST='(.*\.tmp$)|(.*\.log$)|(.*\.svn.*)|(.*\.byqcms.*)'

ONLINE_TMP_DIR="/tmp"

ONLINE_BACKUP_DIR="/home/$SSH_USER/deploy_history/$PROJECT_NAME"
LOCAL_DEPLOY_HISTORY_DIR="/home/$USER/deploy_history/$PROJECT_NAME"

DEPLOY_HISTORY_FILE="$LOCAL_DEPLOY_HISTORY_DIR/deploy_history"
DEPLOY_HISTORY_FILE_BAK="$LOCAL_DEPLOY_HISTORY_DIR/deploy_history.bak"

this_file=`pwd`"/"$0                      # 相关文件所在文件夹 this_file
DEPLOY_TOOLS_DIR=`dirname $this_file`
. $DEPLOY_TOOLS_DIR/utils.sh              # 公共函数库文件
. $DEPLOY_TOOLS_DIR/deploy-cron-conf.sh   # cron脚本配置文件

SSH="sudo -u $SSH_USER ssh"
SCP="sudo -u $SSH_USER scp"

####################################################################################################
########## 使用帮助 ################################################################################

if [ $# -lt 2 ] || [ "$1" != "." ] 
then
    cecho "\n用法:sh $0 . type"
    cecho "\n功能:批量cron脚本上线"
    cecho "ps:  1.使用前请先配置deploy-cron-conf.sh配置文件中PROJECT_SVN_URL/PROJECT_GIT_URL基准cron文件所在的svn/git目录"
    cecho "     2.各type类对应服务器列表配置deploy-cron-conf.sh"
    exit 0;
fi
init
####################################################################################################
########## 目标集群 ################################################################################

project_cron=${projects_cron[$type]}
cron_cluster=${clusters[$type]}

hosts=$cron_cluster                    # 定义需要进行批量操作的服务器列表

####################################################################################################
########## 文件路径/指令/函数定义 ##################################################################


online_cron_file="$ONLINE_TMP_DIR/$project_cron"   # 线上cron备份文件

tmp_dir=$LOCAL_TMP_DIR/tmp              # 脚本产生的临时文件所在目录

if [ ! -d "$tmp_dir" ]; then            # 判断脚产生临时文件目录是否存在
   mkdir $tmp_dir
   chmod -R 777 $tmp_dir
fi

old_cron_file_path=$tmp_dir/$project_cron               # 线上cron在本地的副本文件路径
bench_old_cron_file_path=$LOCAL_TMP_DIR/$project_cron   # 线上基准主机cron在本地的副本文件路径

# 状态记录文件路径
well_file=$tmp_dir/well_cron.txt   # 无需覆盖就已和最新版本cron相同的服务器列表记录文件路径
good_file=$tmp_dir/good_cron.txt   # 覆盖的服务器列表记录文件
bad_file=$tmp_dir/bad_cron.txt     # 未覆盖的服务器列表记录文件

# 线上cron内容导出命令
export_online_cron_cmd="crontab -l > $online_cron_file"

# 删除临时文件命令
clean_online_files_cmd="rm -rf $online_cron_file"

####################################################################################################
##########  步骤1：获取SVN/GIT上最新版本cron到本地（new_cron_file_path） ###########################

if [ -n "$PROJECT_SVN_URL" ]
then
    CURRENT_REVISION=$(get_svn_head_revision $PROJECT_SVN_URL/)
    CURRENT_TIME=$(now)
    LOCAL_SOURCE_DIR=$LOCAL_TMP_DIR/$PROJECT_NAME-$CURRENT_REVISION-$CURRENT_TIME
    export_svn $PROJECT_SVN_URL $LOCAL_SOURCE_DIR $CURRENT_REVISION
elif [ -n "$PROJECT_GIT_URL" ]
then
     CURRENT_TIME=$(now)
     LOCAL_SOURCE_DIR=$LOCAL_TMP_DIR/$PROJECT_NAME-$CURRENT_TIME
     export_git $PROJECT_GIT_URL $LOCAL_SOURCE_DIR $PROJECT_GIT_BRANCH
else
    cecho "\n请在配置文件deploy-cron-conf.sh中填写SVN或GIT的URL" $c_error
    exit 1;
fi

# 最新版本基准文件拿到本地
new_cron_file_path=$LOCAL_SOURCE_DIR/$CRON_DIR/$project_cron
if [ ! -f $new_cron_file_path ]; then
   cecho "\n 此类型基准文件尚未入svn/git!\n" $c_error
   rm -rf $LOCAL_SOURCE_DIR
   exit 1;
fi

##################################################################################################
##########  步骤2：最新版本cron上线 ##############################################################

dos2unix -k $new_cron_file_path      # 保证本地基准文件为unix格式

cecho "\n\n\t--- 进行cron批量覆盖操作 ---\n\n" $c_notify

for host in ${hosts}
do
    cecho "\n$host\n" $c_notify

    ##############################################################################################
    ######  步骤2.1：线上cron导出至本地（old_cron_file_path） ####################################
    ssh_run $host "$export_online_cron_cmd"
    $SCP $host:$online_cron_file $old_cron_file_path

    ##############################################################################################
    ######  步骤2.2：最新版本cron与线上cron作对比  ###############################################

        ##########################################################################################
        ######  步骤2.2.1：已经一致则记录well_cron.txt ###########
        diffs=`diff -Bb $LOCAL_SOURCE_DIR/cron/$project_cron $old_cron_file_path`
        if [ -z "$diffs" ]; then
            echo -e "### $host ###" >> $well_file
            continue
        fi

        ###########################################################################################
        ######  步骤2.2.2：若已确定基准主机则与基准主机cron对比                      ##############
        ######  一致,则最新版本cron覆盖,记录well_cron.txt 不一致，则记录bad_cron.txt ##############
        if [ "" != "$bench_host" ]
        then
            tmp=`diff -Bb $bench_old_cron_file_path $old_cron_file_path`
            if [ -z "$tmp" ]; then
                echo -e "### $host ###" >> $good_file
                cover_online_cron $host $new_cron_file_path $ONLINE_TMP_DIR $online_cron_file
            else
                echo -e "\n\n### $host ###\n" >> $bad_file
                #cat $old_cron_file_path >> $bad_file
            fi
            continue
        fi

    ###########################################################################################
    ######  步骤2.3：若未确定基准主机则最新版本cron与基准主机cron作对比,覆盖  #################
    sleep 1
    vimdiff $LOCAL_SOURCE_DIR/cron/$project_cron $old_cron_file_path
    deploy_confirm "    确认覆盖该类型cron ?"
    if [ 1 != $? ]; then
        deploy_confirm "是否继续！"
        if [ 1 != $? ]; then
            clean
            ssh_run $host "$clean_online_files_cmd"
        	exit 1
        else
            echo -e "\n\n### $host ###\n" >> $bad_file
            ssh_run $host "$clean_online_files_cmd"
            continue
        fi
    else
        bench_host="$host"
        $SCP $bench_host:$online_cron_file "$bench_old_cron_file_path"
        cover_online_cron $bench_host $new_cron_file_path $ONLINE_TMP_DIR $online_cron_file
        echo -e "### $bench_host ###" >> $good_file
        ssh_run $bench_host "$clean_online_files_cmd"
    fi
done

##################################################################################################
##########  步骤3：打印脚本运行结果 ##############################################################
if [ -f "$well_file" ]; then
   cecho "\n\n--- 无需覆盖就已和svn基准文件相同的服务器列表 ---\n" $c_notify
   cat $well_file
fi

if [ -f "$good_file" ]; then
   cecho "\n\n--- 覆盖的服务器 ---\n" $c_notify
   cat $good_file
fi

if [ -f "$bad_file" ]; then
   cecho "\n\n--- 未覆盖的服务器 ---\n" $c_notify
   cat $bad_file
   cecho "\n\n\t--- 线上cron不一致导致存在未覆盖的服务器，请再次运行脚本！ ---\n" $c_notify
else
   cecho "\n\n\t--- 已全量覆盖成功！ ---\n" $c_notify
fi

cecho "\n\n\t--- 脚本执行结束！ ---\n" $c_notify

clean
