<?php
/**
 * Created by PhpStorm.
 * Date: 2016/1/18
 * Time: 14:39
 *
 * 本脚本为日志监控脚本，请勿修改已有监控配置，如需新增监控，只需按格式新增即可
 * crontab脚本举例：
 * '*\/1 * * * * (cd /home/q/system/demo && /usr/bin/lockf -t 0 /tmp/monitor_nginx.lock /usr/local/bin/php src/application/console/crontab/monitor_log.php "project=demor&mid=inter&type=php&count=1" >> logs/monitor_log.log)'
 * 新增监控方法：
 * 1、$alarm_pids 新增数组元素，增加自己的alarm项目标识和pid
 * 2、$alarm_mids 若新增监控的alarm模块号不在数组内，则自行添加数组元素
 * 3、$file_types  按照格式，添加新增监控的标识和详细信息
 */
include (dirname(__FILE__) . '/../console_env.php');

//$kill_cmd = "ps aux|grep 'tail -f -n 0 /home/demo/branches/demo_1/config/server/../..//data/test/online_log/nginx_test.dat' | awk '{print $2}'|xargs kill -9";
//exec($test,$array);

// alarm 项目pid号, 若新建alarm项目可自行增加数组元素
$alarm_pids = array(
    'live_master' => 136,        //e.g. 'master' => 100, 'master'为该alarm项目的标识,可自行命名,尽量与项目相关; 100为alarm项目的pid
);

# alarm报警模块类型 mid
$alarm_mids = array(
    'undefine' => 1,
    'db' => 2,
    'sys' => 3,
    'sdk' => 4,
    'mc' => 5,
    'inter' => 6,
    'kfk' => 7,
    'mongo' => 8,
    'cassandra' => 9,
    'leveldb' => 10,
    'proxy' => 11,
    'timeout' => 12,
    'redis' => 13,
    'back' => 14,
    'front' => 15,
    'zookeeper' => 17,
    'udpserver' => 18,
    'tcpserver' => 19,
);

// 想要监控的日志文件类型，可自行按照格式增加新的日志文件类型
// e.g.
// 'php' => array(                     # 'php'  该类型日志文件的标识,可自行命名
//   'file' => "",                     # 'file' 该类日志文件的路径
//   'preg' => "",                     # 'preg' 对该类日志文件进行解析的正则
//   'alarm_codes' => array(),        # 'alarm_codes' 该类日志要监控的错误日志类型, key为错误码,value为正则解析日志得到的错误标识
//   'alarm_format' => array(),       # 'alarm_format' 该类日志进行格式化输出的方式,格式化后为alarm报警的详细信息, key为自定义的信息字段, value为正则解析日志后得到的数组的键值,
// ),                                  #                 如正则解析一条错误日志得到数组$res,则格式化结果为key=$res[$value],注:若value不为int,则格式化后为key=$value

$file_types = array(
    'php' => array(
        'file' => Config::getConfig('LOG_DIR') . "php.log",
        'preg' => "/(\[)([\w\-\:\s]+)\s+([\w\/]+)(\])\s+([\w]+)\s+([\w\s]+)(\:\s+)([\w\(\)\/\!\s\'\,\.\:]+\s+)(\/[\w\/\.\-]+\s+)([\w\s]+\s+)([\d]+\s*)([\w\s]+)*(\/[\w\/\.\-]+\s+)*([a-z\s]+\s+)*([\d]+\s*)*/",
        'alarm_codes' => array(
            90202 => 'Fatal error',
            90207 => 'Catchable fatal error',
        ),
        'alarm_format' => array(
            'time' => 2,
            'hostname' => gethostname(),
            'error_type' => 6,
            'request' => 9,
            'line' => 11,
            'detail'=> 0,  //显示完整日志
        ),
    ),
    'nginx' => array(
        'file' => "/data/nginx/logs/web/access.log",
        'preg' => "/([\d+\.\,]+)\s+-\s+-\s+(\[[\w\/\:\s\+]+\])\s+\"([\w]+)\s+([\w\/\.\?\=\&\*\%\-]+)\s+([\w\/\.]+)\"\s+([\d]+)\s+([\d]+)\s+(\"([\w\.\?\=\&\*\%\-\/\(\)\s\;\,\:\[\]]+)\"\s+)+([\d\.]+)\s+([\d\.]+)\s+([\d\.\-]+)/",
        'alarm_codes' => array(
            500 => '500',
            501 => '501',
            502 => '502',
            503 => '503',
            504 => '504',
            505 => '505',
            506 => '506',
            507 => '507',
            508 => '508',
            509 => '509',
        ),
        'alarm_format' => array(
            'time' => 2,
            'error_type' => 6,
            'client_ip' => 1,
            'hostname' => gethostname(),
            'request' => 4,
            'request_time' => 11,
            'upstream_time' => 12,
            'body_sent_bytes' => 7,
        ),
    ),
);

$params = array();

if ($argc > 1) {
    parse_str ( $argv [1], $params );
}else {
    exit;
}

$alarm_pid = $alarm_pids[$params['project']];
$alarm_mid = $alarm_mids[$params['mid']];
$file_type = $file_types[$params['type']];
$count = $params['count'];  // alarm报警特殊参数设置, 如无特别需求，可无需设置

$monitor = new MonitorLogModel();

if (!empty($count)) {
    $alarm_params = array(
        'count' => intval($params['count']),              //  count:错误次数,默认为1
        'type' => "set",     //  type:类型,默认为increment,累加$count数,可以设置为set,指定值为count
    );
    $monitor->start($alarm_pid, $alarm_mid, $file_type, $alarm_params);
} else {
    $monitor->start($alarm_pid, $alarm_mid, $file_type);
}




