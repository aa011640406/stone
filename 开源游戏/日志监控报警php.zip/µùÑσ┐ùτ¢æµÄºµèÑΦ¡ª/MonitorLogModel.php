<?php
/**
 * Created by PhpStorm.
 * Date: 2016/1/19
 * Time: 21:01
 *
 * 日志监控
 *
 */
require_once "/home/q/php/Alarm/Alarm.php";

class MonitorLogModel
{
    private $file;
    private $handle;
    private $descriptorspec;
    private $preg;
    private $alarm_pid;
    private $alarm_mid;
    private $alarm_params;
    private $alarm_codes;
    private $alarm_format;

    //读文件失败最大行数
    const MAX_LINES = 10000;

    //每次读文件跳行数
    const MAX_SKIPS = 1;

    public function __construct()
    {
    }

    public function start($alarm_pid, $alarm_mid, $file_type, $alarm_params = array())
    {
        Logger::logBusiness(__FILE__, __LINE__, 'alarm monitor start', array('pid'=>$alarm_pid, 'mid'=>$alarm_mid, 'type'=>$file_type, 'params'=>$alarm_params));
        $this->alarm_pid = $alarm_pid;
        $this->alarm_mid = $alarm_mid;
        $this->alarm_params = $alarm_params;
        $this->file = $file_type['file'];
        $this->preg = $file_type['preg'];
        $this->alarm_codes = $file_type['alarm_codes'];
        $this->alarm_format = $file_type['alarm_format'];
        $this->createMonitor();
    }

    //创建监听
    public function createMonitor()
    {
        $this->descriptorspec = array(
            0 => array("pipe", "r"),  // stdin is a pipe that the child will read from
            1 => array("pipe", "w"),  // stdout is a pipe that the child will write to
            2 => array("pipe", "r")   // stderr is a file to write to
        );
        $process = proc_open("tail -f -n 0 " . $this->file, $this->descriptorspec,  $pipes); //如果对所监测的文件进行vim保存，会导致原文件被vim后新的文件replace，该进程找不到原来文件的索引节点，导致监测失败
        Logger::logBusiness(__FILE__, __LINE__, "tail -f -n 0 " . $this->file);
        $this->handle = $pipes[1];
        stream_set_blocking($this->handle, false);
        $gotFalse = 0;
        $i = 0;
        while ( !feof($this->handle) ) {
            $buffer = fgets($this->handle);
            if ($buffer === false) {
                if ($gotFalse >= self::MAX_LINES) {
                    $s = proc_get_status($process);
                    posix_kill($s['pid'], SIGKILL);
                    exit(0);
                } else {
                    $gotFalse++;
                    sleep(1);
                    continue;
                }
            }
            $gotFalse = 0;
            $i++;
            if ($i < self::MAX_SKIPS) {
                continue;
            }
            $this->alarmSend($buffer);
        }

    }

    public function alarmSend($buffer)
    {
        $matchOver = false;
        $warn = array();
        if ($ret = $this->parseLine($buffer)) {
            $error_type = $ret[$this->alarm_format['error_type']];
            if (in_array($error_type, $this->alarm_codes)) {
                $matchOver = true;
                $warn = $this->alarm_format;
                foreach ($warn as $key => $value) {
                    $warn[$key] = is_int($value)?$ret[$value]:$value;
                }
            }
        }

        if ($matchOver) {
            //error_log(var_export($warn, true) . "", 3, QFrameConfig::getConfig('LOG_DIR') . "/monitor.log");
            $server_ip = empty($warn['server_ip']) ? '' : $warn['server_ip'];
            $client_ip = empty($warn['client_ip']) ? '' : $warn['client_ip'];
            $script = empty($warn['request']) ? '' : $warn['request'];
            $count = empty($this->alarm_params['count']) ? 1 : intval($this->alarm_params['count']);
            $type = empty($this->alarm_params['type']) ? 'increment' : $this->alarm_params['type'];
            Logger::logBusiness(__FILE__, __LINE__, "alarm send start");
            $ret = Alarm::send($this->alarm_pid, $this->alarm_mid, array_flip($this->alarm_codes)[$error_type], json_encode($warn), $server_ip, $client_ip, $script, $count, $type);
            Logger::logBusiness(__FILE__, __LINE__, "alarm send success", array('result' => $ret));
        }
        return $matchOver;
    }

    //解析日志记录
    public function parseLine($buffer)
    {
        preg_match($this->preg, $buffer, $result);

        return $result;
    }

}
