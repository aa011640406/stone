addEvent = function(){
        var _li = document.getElementsByName('tagli');
        for(var i=0;i<_li.length;i++)
        {
            _li[i].onmouseover = function(){
                chColor(this ,"#CCC");
            };
            _li[i].onmouseout = function(){
                chColor(this ,"#FFFFFF");
            };
        }
    };
    chColor = function(obj ,color){
        obj.style.background = color;
    };
    window.onload = function(){
        addEvent();
    };