function Sound()
{
	
}


Sound.prototype.play = function(name)
{
	var ss = document.getElementById(name);
	ss.play();
};

















